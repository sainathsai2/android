package com.example.weburl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=findViewById(R.id.b);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s="https://www.google.com/";
                Uri url=Uri.parse(s);
                Intent i= new Intent();
                i.setAction(Intent.ACTION_VIEW);
                i.setData(url);
                if(i.resolveActivity(getPackageManager())!=null){
                    startActivity(i);
                }

            }
        });
    }
}
